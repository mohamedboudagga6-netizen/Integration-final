#include <gtk/gtk.h>



void on_GCIA_buttonEnregistrer_clicked(GtkWidget *button, gpointer user_data);

void on_GCIA_comboType_entry_changed(GtkEntry *entry, gpointer user_data);

void on_GCIA_comboType_list_selected(GtkList *list, GtkWidget *child, gpointer user_data);




void
on_GCIA_radiobutton2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIA_radiobutton3_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIA_radiobutton4_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIA_spinbutton1_value_changed      (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_GCIP_buttonAjouter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIA_radiobutton3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIA_radiobuttonE_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIM_spinbutton1_value_changed      (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_GCIM_buttonEnregistrer_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_radiobuttonTP_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIM_radiobuttonAU_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIM_radiobuttonEA_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIP_buttonAjouter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIP_buttonModifier_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_buttonChercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_radiobuttonAU_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIM_radiobuttonAU_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_GCIA_buttonprecedent_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIA_buttonquitter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_buttonprecedent_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_buttonquitter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIP_treeview_realize               (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_GCIP_buttonquitter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIP_button_Supprimer_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIP_button_Actualiser_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIP_button_Chercher_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIA_buttonGestion_centre_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIA_buttonModifier_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_buttonAjouter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIM_buttonGestion_centre_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_GCIA_Renitialiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_TIEC_buttonPrecedent_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_TIEC_buttonEnregistrer_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_TIEC_buttonQuitter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_TIEC_spinbuttonJour_value_changed   (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_TIEC_spinbuttonMois_value_changed   (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_TIEC_spinbuttonAnnees_value_changed (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_TIEC_radiobuttonPermanent_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_radiobuttonContractuel_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_radiobuttonVacataire_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_checkbuttonMatin_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_checkbuttonApr__s_midi_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_checkbuttonSoir_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_checkbuttonWeek_end_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_buttonRenitialiser_clicked     (GtkButton       *button,
                                        gpointer         user_data);
