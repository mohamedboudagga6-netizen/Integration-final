

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "centre.h"

// ========================================
// AJOUTER UN CENTRE
// ========================================
void Ajouter(const char *id, const char *nom, const char *adresse, const char *tel,
             const char *email, const char *type, int capacite,
             const char *public_vise, const char *description)
{
    FILE *f = fopen("centre.txt", "a");
    if (!f) {
        printf("Erreur : impossible d'ouvrir centre.txt\n");
        return;
    }
    fprintf(f, "%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\n",
            id, nom, adresse, tel, email, type, capacite, public_vise, description);
    fclose(f);
}

// ========================================
// CHERCHER UN CENTRE PAR ID
// ========================================
Centre Chercher(const char *id)
{
    Centre c = {0};
    FILE *f = fopen("centre.txt", "r");
    if (!f) return c;

    char ligne[2048];
    while (fgets(ligne, sizeof(ligne), f)) {
        Centre temp;
        if (sscanf(ligne, "%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%d\t%[^\t]\t%[^\n]",
                   temp.id, temp.nom, temp.adresse, temp.tel, temp.email,
                   temp.type, &temp.capacite, temp.public_vise, temp.description) == 9) {
            if (strcmp(temp.id, id) == 0) {
                fclose(f);
                return temp;
            }
        }
    }
    fclose(f);
    return c;
}

// ========================================
// MODIFIER UN CENTRE
// ========================================
int Modifier(const char *id, const char *nom, const char *adresse, const char *tel,
             const char *email, const char *type, int capacite,
             const char *public_vise, const char *description)
{
    FILE *f = fopen("centre.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    if (!f || !temp) {
        if (f) fclose(f);
        if (temp) fclose(temp);
        return 0;
    }

    char ligne[2048];
    int trouve = 0;

    while (fgets(ligne, sizeof(ligne), f)) {
        Centre c;
        if (sscanf(ligne, "%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%d\t%[^\t]\t%[^\n]",
                   c.id, c.nom, c.adresse, c.tel, c.email,
                   c.type, &c.capacite, c.public_vise, c.description) == 9) {
            if (strcmp(c.id, id) == 0) {
                fprintf(temp, "%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\n",
                        id, nom, adresse, tel, email, type, capacite, public_vise, description);
                trouve = 1;
            } else {
                fputs(ligne, temp);
            }
        } else {
            fputs(ligne, temp);
        }
    }

    fclose(f);
    fclose(temp);

    if (trouve) {
        remove("centre.txt");
        rename("temp.txt", "centre.txt");
        return 1;
    } else {
        remove("temp.txt");
        return 0;
    }
}

// ========================================
// AFFICHER TOUS LES CENTRES DANS LE TREEVIEW (8 COLONNES)
// ========================================
enum {
    COL_ID,
    COL_NOM,
    COL_ADRESSE,
    COL_TEL,
    COL_EMAIL,
    COL_TYPE,
    COL_CAPACITE,
    COL_PUBLIC,
    COL_DESCRIPTION,
    COL_COUNT
};

void Afficher_Centres(GtkWidget *treeview)
{
    GtkListStore *store;
    GtkTreeIter iter;
    GtkCellRenderer *renderer = gtk_cell_renderer_text_new();

    // Récupérer ou créer le modèle
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(treeview)));
    if (!store) {
        // Créer les colonnes une seule fois
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "ID", renderer, "text", COL_ID, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Nom", renderer, "text", COL_NOM, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Adresse", renderer, "text", COL_ADRESSE, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Téléphone", renderer, "text", COL_TEL, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Email", renderer, "text", COL_EMAIL, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Type", renderer, "text", COL_TYPE, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Capacité", renderer, "text", COL_CAPACITE, NULL);
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Public", renderer, "text", COL_PUBLIC, NULL);
        // Description tronquée
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview), -1, "Description", renderer, "text", COL_DESCRIPTION, NULL);

        store = gtk_list_store_new(COL_COUNT,
                                   G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                                   G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                                   G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }

    gtk_list_store_clear(store);

    FILE *f = fopen("centre.txt", "r");
    if (!f) return;

    char ligne[2048];
    Centre c;
    char desc_short[101];

    while (fgets(ligne, sizeof(ligne), f)) {
        if (sscanf(ligne, "%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%d\t%[^\t]\t%[^\n]",
                   c.id, c.nom, c.adresse, c.tel, c.email,
                   c.type, &c.capacite, c.public_vise, c.description) == 9) {

            // Tronquer description pour l'affichage
            strncpy(desc_short, c.description, 100);
            desc_short[100] = '\0';
            if (strlen(c.description) > 100) strcat(desc_short, "...");

            char capacite_str[20];
            sprintf(capacite_str, "%d", c.capacite);

            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               COL_ID, c.id,
                               COL_NOM, c.nom,
                               COL_ADRESSE, c.adresse,
                               COL_TEL, c.tel,
                               COL_EMAIL, c.email,
                               COL_TYPE, c.type,
                               COL_CAPACITE, capacite_str,
                               COL_PUBLIC, c.public_vise,
                               COL_DESCRIPTION, desc_short,
                               -1);
        }
    }
    fclose(f);
}


