#include <gtk/gtk.h>

void
on_GC_notebook_value_changed           (GtkNotebook     *notebook,
                                        GtkNotebookPage *page,
                                        guint            page_num,
                                        gpointer         user_data);

void
on_Ac_treeview_check_resize            (GtkContainer    *container,
                                        gpointer         user_data);

void
on_Ac_buttonajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ac_buttonmodifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ac_buttonsupprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ac_buttonquitter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ac_buttonrechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ac_buttonprecedent_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Aj_spinbutton1_value_changed        (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_Aj_buttonprecedent_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Aj_buttonEnregistrer_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Aj_buttonquitter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Aj_spinbutton2_value_changed        (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_calendar1_day_selected              (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_Aj_radiobutton1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Aj_radiobutton2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Aj_radiobuttonM_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mod_buttonprecedent_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Mod_buttonEnregistrer_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Mod_buttonquitter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_calendar2_day_selected              (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_Mod_spinbutton2_value_changed       (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_Mod_spinbutton1_value_changed       (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_Mod_radiobutton2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mod_radiobuttonTP_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mod_radiobuttonEA_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mod_buttonChercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_spinbutton1_value_changed           (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_spinbutton4_value_changed           (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_spinbutton5_value_changed           (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_spinbutton6_value_changed           (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TIEC_window_show(GtkWidget *widget, gpointer user_data);

void
on_button_administrateur_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_membre_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_se_connecter_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_quitter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_quitter2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_conn1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
