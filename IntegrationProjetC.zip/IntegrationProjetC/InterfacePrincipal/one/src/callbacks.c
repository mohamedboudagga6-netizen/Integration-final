#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

int result;

///////////////////////////f_quitter/////////////////////////
void confirm_quit(GtkWidget *parent_window) {
    GtkWidget *dialog;
    GtkResponseType result;

    dialog = gtk_message_dialog_new(GTK_WINDOW(parent_window),
                                    GTK_DIALOG_MODAL,
                                    GTK_MESSAGE_WARNING,
                                    GTK_BUTTONS_NONE,
                                    "Vous êtes sûr de quitter FitVerse ?");

    gtk_dialog_add_button(GTK_DIALOG(dialog), "Oui", GTK_RESPONSE_YES);
    gtk_dialog_add_button(GTK_DIALOG(dialog), "Non", GTK_RESPONSE_NO);

    result = gtk_dialog_run(GTK_DIALOG(dialog));

    if (result == GTK_RESPONSE_YES) {
        gtk_main_quit();
    }

    gtk_widget_destroy(dialog);
}

/////////////////////////////////Interface Bienvenue/////////////////////////////////////////////////////
void
on_IPbuttonQuitter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	 confirm_quit(GTK_WIDGET(user_data));
}


void
on_buttonAide_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_IPbuttonInfo_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_IPbuttonAdmin_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *Authen_Admin;
        Authen_Admin = create_Authen_Admin();
        gtk_widget_set_size_request (Authen_Admin, 480, 320);
        gtk_widget_show (Authen_Admin);
}


void
on_IPbuttonMembre_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_IPbuttonEntraineur_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////Interface Gestion pour Admin //////////////////////////////////////////
void
on_IPAbuttonCentre_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
    
    result = system("cd ../../../Omar/src/ && ./fitverse &");
    
    if (result != 0) {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(NULL,
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Erreur: Impossible d'ouvrir l'application de gestion des centres!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_IPAbuttonEquipement_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    result = system("cd ../../../sarra/src/ && ./project5 &");
    
    if (result != 0) {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(NULL,
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Erreur: Impossible d'ouvrir l'application de gestion des équipements!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_IPAbuttonEntraineur_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    result = system("cd ../../../Mohamed/src/ && ./projet1 &");
    
    if (result != 0) {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(NULL,
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Erreur: Impossible d'ouvrir l'application de gestion des centres!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_IPAbuttonMembre_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_IPAbuttonCour_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
    result = system("cd ../../../Rihem/src/ && ./cours &");
    
    if (result != 0) {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(NULL,
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Erreur: Impossible d'ouvrir l'application de gestion des centres!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_IPAbuttonEvenement_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    result = system("cd ../../../Hela/src/ && ./fitverse &");
    
    if (result != 0) {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(NULL,
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Erreur: Impossible d'ouvrir l'application de gestion des centres!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_IPAbuttonQuitter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 	 confirm_quit(GTK_WIDGET(user_data));
}
/////////////////////////////Authentification Admin///////////////////////////////////////////////////////
void
on_buttonAuthentifierAdmin_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entryNom, *entryMot;
    GtkWidget *Authen_Admin;
    const gchar *nom, *motDePasse;
    FILE *fichier;
    char ligne[256];
    char nomFichier[100], motFichier[100];
    int trouve = 0;
    
    Authen_Admin = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    entryNom = lookup_widget(Authen_Admin, "entryNomAdmin");
    entryMot = lookup_widget(Authen_Admin, "entryMotAdmin");
    
    if (entryNom == NULL || entryMot == NULL) {
        g_print("ERREUR: Impossible de trouver les entries!\n");
        return;
    }
  
    nom = gtk_entry_get_text(GTK_ENTRY(entryNom));
    motDePasse = gtk_entry_get_text(GTK_ENTRY(entryMot));
    
    if (strlen(nom) == 0 || strlen(motDePasse) == 0) {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(GTK_WINDOW(Authen_Admin),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_WARNING,
                                        GTK_BUTTONS_OK,
                                        "Veuillez remplir tous les champs!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fichier = fopen("admin.txt", "r");
    if (fichier == NULL) {
        fichier = fopen("../admin.txt", "r");
        if (fichier == NULL) {
            GtkWidget *dialog;
            dialog = gtk_message_dialog_new(GTK_WINDOW(Authen_Admin),
                                            GTK_DIALOG_MODAL,
                                            GTK_MESSAGE_ERROR,
                                            GTK_BUTTONS_OK,
                                            "Erreur: Fichier admin.txt introuvable!");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return;
        }
    }
    
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {

        ligne[strcspn(ligne, "\n")] = 0;
        
        if (sscanf(ligne, "%s %s", nomFichier, motFichier) == 2) {
            if (strcmp(nom, nomFichier) == 0 && strcmp(motDePasse, motFichier) == 0) {
                trouve = 1;
                break;
            }
        }
    }
    
    fclose(fichier);
    
    if (trouve) {
        GtkWidget *GestionAdmin;
        GestionAdmin = create_GestionAdmin();
        gtk_widget_set_size_request (GestionAdmin, 730, 470);
        gtk_widget_show(GestionAdmin);
        
        gtk_widget_destroy(Authen_Admin);
        
    } else {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(GTK_WINDOW(Authen_Admin),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Nom d'utilisateur ou mot de passe incorrect!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        
        
        gtk_entry_set_text(GTK_ENTRY(entryNom), "");
        gtk_entry_set_text(GTK_ENTRY(entryMot), "");
   }
}


void
on_buttonAnnulerAdmin_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *Authen_Admin;
        Authen_Admin = gtk_widget_get_toplevel(GTK_WIDGET(button));
	gtk_widget_destroy(Authen_Admin);
}

