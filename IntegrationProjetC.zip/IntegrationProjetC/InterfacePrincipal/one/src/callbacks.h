#include <gtk/gtk.h>


void
on_IPbuttonQuitter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAide_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPbuttonInfo_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPbuttonAdmin_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPbuttonMembre_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPbuttonEntraineur_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonCentre_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonEquipement_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonEntraineur_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonMembre_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonCour_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonEvenement_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_IPAbuttonQuitter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAuthentifierAdmin_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAnnulerAdmin_clicked          (GtkButton       *button,
                                        gpointer         user_data);
