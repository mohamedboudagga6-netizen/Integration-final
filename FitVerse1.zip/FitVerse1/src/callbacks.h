#include <gtk/gtk.h>


void
on_button_chercher_evenement_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ouvrir_ajout_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifer_ouvrire_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_hela_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_window_gestion_evenement_show       (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_window_ajouter_evenement_show       (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_window_modifier_evenement_show      (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_radiobutton_annulee_mod_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_terminer_mod_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_encours_mod_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modfier_event_hela_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_annulee_mod_hela_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_event_hela_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_hela_evenment_cursor_changed
                                        (GtkTreeView     *treeview,
                                        gpointer         user_data);

void
on_windowsinscireevent_show            (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_treeview_sincrire_event_cursor_changed
                                        (GtkTreeView     *treeview,
                                        gpointer         user_data);

void
on_button_sinscire_event_hela_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_voir_mes_inscription_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_annuler_inscription_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_sincrire_event_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_encours_mod_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_terminer_mod_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
