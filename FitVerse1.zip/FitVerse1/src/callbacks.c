#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "evenement.h"
#include "centre.h"

/* ============================================= */
/* VARIABLES GLOBALES POUR RADIO BUTTONS */
/* ============================================= */
static int z = 1;  // Statut pour AJOUTER (1=en_cours, 2=terminer, 3=annule)
static int w = 1;  // Statut pour MODIFIER (1=en_cours, 2=terminer, 3=annule)

/* ============================================= */
/* HELPER FUNCTION - Get active text from combo */
/* ============================================= */
gchar* get_combo_box_active_text(GtkComboBox *combo_box) {
    GtkTreeIter iter;
    GtkTreeModel *model;
    gchar *text = NULL;
    
    if (gtk_combo_box_get_active_iter(combo_box, &iter)) {
        model = gtk_combo_box_get_model(combo_box);
        gtk_tree_model_get(model, &iter, 0, &text, -1);
    }
    
    return text;
}

/* ============================================= */
/* HELPER FUNCTION - Get text from ComboBoxEntry */
/* ============================================= */
const gchar* get_combo_box_entry_text(GtkWidget *comboboxentry) {
    GtkWidget *entry = gtk_bin_get_child(GTK_BIN(comboboxentry));
    if (entry && GTK_IS_ENTRY(entry)) {
        return gtk_entry_get_text(GTK_ENTRY(entry));
    }
    return "";
}

/* ============================================= */
/* HELPER FUNCTION - Set text in ComboBoxEntry */
/* ============================================= */
void set_combo_box_entry_text(GtkWidget *comboboxentry, const gchar *text) {
    GtkWidget *entry = gtk_bin_get_child(GTK_BIN(comboboxentry));
    if (entry && GTK_IS_ENTRY(entry)) {
        gtk_entry_set_text(GTK_ENTRY(entry), text);
    }
}

/* ============================================= */
/* GESTION ÉVÉNEMENTS - FENÊTRE PRINCIPALE */
/* ============================================= */

void on_window_gestion_evenement_show(GtkWidget *widget, gpointer user_data) {
    GtkWidget *treeview = lookup_widget(widget, "treeview_hela_evenment");
    if (treeview) {
        afficher_evenements(treeview);
    }
}

void on_button_chercher_evenement_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *entry = lookup_widget(window, "entry_hela_recherche");
    GtkWidget *treeview = lookup_widget(window, "treeview_hela_evenment");

    if (!entry || !treeview) return;

    const gchar *critere = gtk_entry_get_text(GTK_ENTRY(entry));

    if (strlen(critere) == 0) {
        afficher_evenements(treeview);
    } else {
        int found = rechercher_evenements(critere, treeview);
        if (found == 0) {
            GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
                GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK,
                "Aucun événement trouvé avec ce critère.");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
        }
    }
}

void on_button_ouvrir_ajout_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window_ajout = create_window_ajouter_evenement();
    gtk_widget_show(window_ajout);
}

void on_button_modifer_ouvrire_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *treeview = lookup_widget(window, "treeview_hela_evenment");

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Veuillez sélectionner un événement à modifier.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    gint id;
    gtk_tree_model_get(model, &iter, 0, &id, -1);

    evenement ev = trouver_evenement(id);
    if (ev.id_event == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK,
            "Événement introuvable !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    GtkWidget *win_mod = create_window_modifier_evenement();

    // Remplir les champs
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(win_mod, "entry_nom_event_mod")), ev.nom_event);
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(win_mod, "description_event_mod")), ev.description);
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(win_mod, "entry_salle_modif_hela")), ev.salle);

    // Set prix value in comboboxentry
    char prix_str[20];
    snprintf(prix_str, sizeof(prix_str), "%.2f", ev.prix);
    GtkWidget *combo_prix = lookup_widget(win_mod, "comboboxentry_modif_prix_hela");
    if (combo_prix) {
        set_combo_box_entry_text(combo_prix, prix_str);
    }

    gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(win_mod, "spinbutton_mod_jrs_hela")), ev.date_e.j);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(win_mod, "spinbutton_mois_mod_hela")), ev.date_e.m);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(win_mod, "spinbutton_annee_mod_hela")), ev.date_e.a);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(win_mod, "spinbutton_heure_mod")), ev.heure_e.heure);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(win_mod, "spinbutton_min_hela_mod")), ev.heure_e.minute);

    // Sélectionner le bon type dans le combobox
    GtkComboBox *cb_type = GTK_COMBO_BOX(lookup_widget(win_mod, "combobox_type_event_mod"));
    GtkTreeModel *model_type = gtk_combo_box_get_model(cb_type);
    GtkTreeIter iter_type;
    gboolean valid = gtk_tree_model_get_iter_first(model_type, &iter_type);
    int i = 0;
    while (valid) {
        gchar *text;
        gtk_tree_model_get(model_type, &iter_type, 0, &text, -1);
        if (g_strcmp0(text, ev.type_event) == 0) {
            gtk_combo_box_set_active(cb_type, i);
            g_free(text);
            break;
        }
        g_free(text);
        valid = gtk_tree_model_iter_next(model_type, &iter_type);
        i++;
    }

    // Sélectionner le bon centre
    GtkComboBox *cb_centre = GTK_COMBO_BOX(lookup_widget(win_mod, "combobox_centre_mod_event"));
    remplir_combobox_centres(GTK_WIDGET(cb_centre));
    GtkTreeModel *model_centre = gtk_combo_box_get_model(cb_centre);
    GtkTreeIter iter_centre;
    valid = gtk_tree_model_get_iter_first(model_centre, &iter_centre);
    i = 0;
    while (valid) {
        gchar *text;
        gtk_tree_model_get(model_centre, &iter_centre, 0, &text, -1);
        if (g_strcmp0(text, ev.centre) == 0) {
            gtk_combo_box_set_active(cb_centre, i);
            g_free(text);
            break;
        }
        g_free(text);
        valid = gtk_tree_model_iter_next(model_centre, &iter_centre);
        i++;
    }

    // Initialiser w selon le statut
    if (g_strcmp0(ev.statut, "en_cours") == 0) {
        w = 1;
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(win_mod, "radiobutton_encours_mod")), TRUE);
    } else if (g_strcmp0(ev.statut, "terminer") == 0) {
        w = 2;
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(win_mod, "radiobutton_terminer_mod")), TRUE);
    } else {
        w = 3;
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(win_mod, "radiobutton_annulee_mod")), TRUE);
    }

    g_object_set_data(G_OBJECT(win_mod), "event_id", GINT_TO_POINTER(ev.id_event));
    g_object_set_data(G_OBJECT(win_mod), "parent_window", window);
    gtk_widget_show(win_mod);
}

void on_button_supp_hela_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *treeview = lookup_widget(window, "treeview_hela_evenment");

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *d = gtk_message_dialog_new(GTK_WINDOW(window), GTK_DIALOG_MODAL,
            GTK_MESSAGE_WARNING, GTK_BUTTONS_OK, "Sélectionnez un événement à supprimer.");
        gtk_dialog_run(GTK_DIALOG(d));
        gtk_widget_destroy(d);
        return;
    }

    gint id;
    gchar *nom;
    gtk_tree_model_get(model, &iter, 0, &id, 1, &nom, -1);

    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
        GTK_DIALOG_MODAL, GTK_MESSAGE_QUESTION, GTK_BUTTONS_YES_NO,
        "Supprimer l'événement \"%s\" ?", nom);
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_YES) {
        supprimer_evenement(id);
        afficher_evenements(treeview);
        GtkWidget *ok = gtk_message_dialog_new(GTK_WINDOW(window), GTK_DIALOG_MODAL,
            GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Supprimé !");
        gtk_dialog_run(GTK_DIALOG(ok));
        gtk_widget_destroy(ok);
    }
    gtk_widget_destroy(dialog);
    g_free(nom);
}

/* ============================================= */
/* FENÊTRE AJOUTER */
/* ============================================= */

void on_window_ajouter_evenement_show(GtkWidget *widget, gpointer user_data) {
    // Remplir le combobox des centres
    GtkWidget *combo_centre = lookup_widget(widget, "combobox_centre_hela");
    if (combo_centre) {
        remplir_combobox_centres(combo_centre);
    }

    // Par défaut : en cours
    GtkWidget *radio = lookup_widget(widget, "radiobutton_encours");
    if (radio) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio), TRUE);
        z = 1;
    }
}

void on_button_ajouter_event_hela_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));

    const gchar *nom = gtk_entry_get_text(GTK_ENTRY(lookup_widget(win, "entry_nom_event")));
    const gchar *desc = gtk_entry_get_text(GTK_ENTRY(lookup_widget(win, "entry_description_hela")));
    const gchar *salle = gtk_entry_get_text(GTK_ENTRY(lookup_widget(win, "entry_salle_hela")));
    
    // Get prix from comboboxentry
    GtkWidget *combo_prix = lookup_widget(win, "comboboxentry_prix_hela");
    const gchar *prix_str = get_combo_box_entry_text(combo_prix);
    float prix = atof(prix_str);
    
    // Use helper function to get combo box text
    gchar *type = get_combo_box_active_text(GTK_COMBO_BOX(lookup_widget(win, "combobox_type_hela")));
    gchar *centre = get_combo_box_active_text(GTK_COMBO_BOX(lookup_widget(win, "combobox_centre_hela")));

    int j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_jrs_hela")));
    int m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_mois_hela")));
    int a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_annee_hela")));
    int h = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_heure")));
    int min = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton5")));

    if (strlen(nom) < 3) {
        GtkWidget *d = gtk_message_dialog_new(GTK_WINDOW(win), GTK_DIALOG_MODAL,
            GTK_MESSAGE_WARNING, GTK_BUTTONS_OK, "Nom trop court !");
        gtk_dialog_run(GTK_DIALOG(d));
        gtk_widget_destroy(d);
        g_free(type); g_free(centre);
        return;
    }

    if (strlen(salle) < 1) {
        GtkWidget *d = gtk_message_dialog_new(GTK_WINDOW(win), GTK_DIALOG_MODAL,
            GTK_MESSAGE_WARNING, GTK_BUTTONS_OK, "Veuillez spécifier une salle !");
        gtk_dialog_run(GTK_DIALOG(d));
        gtk_widget_destroy(d);
        g_free(type); g_free(centre);
        return;
    }

    if (prix <= 0) {
        GtkWidget *d = gtk_message_dialog_new(GTK_WINDOW(win), GTK_DIALOG_MODAL,
            GTK_MESSAGE_WARNING, GTK_BUTTONS_OK, "Le prix doit être supérieur à 0 !");
        gtk_dialog_run(GTK_DIALOG(d));
        gtk_widget_destroy(d);
        g_free(type); g_free(centre);
        return;
    }

    evenement ev = {0};
    strcpy(ev.nom_event, nom);
    strcpy(ev.type_event, type ? type : "Autre");
    strcpy(ev.centre, centre ? centre : "Non_spécifié");
    strcpy(ev.salle, salle);
    strcpy(ev.description, desc);
    ev.prix = prix;
    ev.date_e.j = j; ev.date_e.m = m; ev.date_e.a = a;
    ev.heure_e.heure = h; ev.heure_e.minute = min;

    // Utiliser la variable z
    if (z == 1) strcpy(ev.statut, "en_cours");
    else if (z == 2) strcpy(ev.statut, "terminer");
    else strcpy(ev.statut, "Annulé");

    ajouter_evenement(ev);

    GtkWidget *ok = gtk_message_dialog_new(GTK_WINDOW(win), GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Événement ajouté !");
    gtk_dialog_run(GTK_DIALOG(ok));
    gtk_widget_destroy(ok);

    // NOUVEAU CODE: Rafraîchir le treeview de la fenêtre principale
    // Chercher la fenêtre de gestion des événements parmi les fenêtres ouvertes
    GList *windows = gtk_window_list_toplevels();
    GList *iter_win;
    for (iter_win = windows; iter_win != NULL; iter_win = iter_win->next) {
        GtkWidget *window = GTK_WIDGET(iter_win->data);
        if (GTK_IS_WINDOW(window)) {
            // Chercher le treeview dans cette fenêtre
            GtkWidget *treeview = lookup_widget(window, "treeview_hela_evenment");
            if (treeview) {
                // Rafraîchir le treeview
                afficher_evenements(treeview);
                break;
            }
        }
    }
    g_list_free(windows);

    // Fermer la fenêtre d'ajout
    gtk_widget_destroy(win);
    
    // Libérer la mémoire
    g_free(type);
    g_free(centre);
    
    // Réinitialiser z
    z = 1;
}

void on_button_annule_event_hela_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_destroy(gtk_widget_get_toplevel(GTK_WIDGET(button)));
    z = 1;
}

/* ============================================= */
/* FENÊTRE MODIFIER */
/* ============================================= */

void on_window_modifier_evenement_show(GtkWidget *widget, gpointer user_data) {
    GtkWidget *combo_centre = lookup_widget(widget, "combobox_centre_mod_event");
    if (combo_centre) {
        remplir_combobox_centres(combo_centre);
    }
}

void on_button_modfier_event_hela_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    int id = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(win), "event_id"));

    if (id <= 0) return;

    const gchar *nom = gtk_entry_get_text(GTK_ENTRY(lookup_widget(win, "entry_nom_event_mod")));
    const gchar *desc = gtk_entry_get_text(GTK_ENTRY(lookup_widget(win, "description_event_mod")));
    const gchar *salle = gtk_entry_get_text(GTK_ENTRY(lookup_widget(win, "entry_salle_modif_hela")));
    
    // Get prix from comboboxentry
    GtkWidget *combo_prix = lookup_widget(win, "comboboxentry_modif_prix_hela");
    const gchar *prix_str = get_combo_box_entry_text(combo_prix);
    float prix = atof(prix_str);
    
    // Use helper function
    gchar *type = get_combo_box_active_text(GTK_COMBO_BOX(lookup_widget(win, "combobox_type_event_mod")));
    gchar *centre = get_combo_box_active_text(GTK_COMBO_BOX(lookup_widget(win, "combobox_centre_mod_event")));

    int j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_mod_jrs_hela")));
    int m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_mois_mod_hela")));
    int a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_annee_mod_hela")));
    int h = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_heure_mod")));
    int min = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(win, "spinbutton_min_hela_mod")));

    evenement ev = trouver_evenement(id);
    ev.id_event = id;
    strcpy(ev.nom_event, nom);
    strcpy(ev.type_event, type ? type : "Autre");
    strcpy(ev.centre, centre ? centre : "Non_spécifié");
    strcpy(ev.salle, salle);
    strcpy(ev.description, desc);
    ev.prix = prix;
    ev.date_e.j = j; ev.date_e.m = m; ev.date_e.a = a;
    ev.heure_e.heure = h; ev.heure_e.minute = min;

    // Utiliser la variable w
    if (w == 1) strcpy(ev.statut, "en_cours");
    else if (w == 2) strcpy(ev.statut, "terminer");
    else strcpy(ev.statut, "Annulé");

    modifier_evenement(ev);

    GtkWidget *ok = gtk_message_dialog_new(GTK_WINDOW(win), GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Événement modifié !");
    gtk_dialog_run(GTK_DIALOG(ok));
    gtk_widget_destroy(ok);

    // Get parent window reference
    GtkWidget *parent = g_object_get_data(G_OBJECT(win), "parent_window");
    if (parent) {
        GtkWidget *tv = lookup_widget(parent, "treeview_hela_evenment");
        if (tv) afficher_evenements(tv);
    }

    gtk_widget_destroy(win);
    g_free(type);
    g_free(centre);
    w = 1;
}

void on_button_annulee_mod_hela_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_destroy(gtk_widget_get_toplevel(GTK_WIDGET(button)));
    w = 1;
}

/* ============================================= */
/* RADIO BUTTONS - FENÊTRE AJOUTER */
/* ============================================= */
void on_radiobutton_encours_toggled(GtkToggleButton *b, gpointer d) {
    if (gtk_toggle_button_get_active(b)) z = 1;
}

void on_radiobutton_terminer_toggled(GtkToggleButton *b, gpointer d) {
    if (gtk_toggle_button_get_active(b)) z = 2;
}

void on_radiobutton_annule_toggled(GtkToggleButton *b, gpointer d) {
    if (gtk_toggle_button_get_active(b)) z = 3;
}

/* ============================================= */
/* RADIO BUTTONS - FENÊTRE MODIFIER */
/* ============================================= */
void on_radiobutton_encours_mod_toggled(GtkToggleButton *b, gpointer d) {
    if (gtk_toggle_button_get_active(b)) w = 1;
}

void on_radiobutton_terminer_mod_toggled(GtkToggleButton *b, gpointer d) {
    if (gtk_toggle_button_get_active(b)) w = 2;
}

void on_radiobutton_annulee_mod_toggled(GtkToggleButton *b, gpointer d) {
    if (gtk_toggle_button_get_active(b)) w = 3;
}

void
on_treeview_hela_evenment_cursor_changed
                                        (GtkTreeView     *treeview,
                                        gpointer         user_data)
{

}
/* ============================================= */
/* FENÊTRE INSCRIPTION MEMBRE AUX ÉVÉNEMENTS */
/* ============================================= */

void on_windowsinscireevent_show(GtkWidget *widget, gpointer user_data) {
    // Afficher tous les événements disponibles dans le treeview
    GtkWidget *treeview = lookup_widget(widget, "treeview_sincrire_event");
    if (treeview) {
        afficher_evenements_disponibles(treeview);
    }
}

void on_button_sinscire_event_hela_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    // Récupérer le CIN du membre
    GtkWidget *entry_cin = lookup_widget(window, "entry_cin_inscription_hela");
    const gchar *cin = gtk_entry_get_text(GTK_ENTRY(entry_cin));
    
    // Vérifier que le CIN n'est pas vide
    if (strlen(cin) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Veuillez entrer votre CIN !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    // Vérifier qu'un événement est sélectionné
    GtkWidget *treeview = lookup_widget(window, "treeview_sincrire_event");
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Veuillez sélectionner un événement !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    // Récupérer l'ID de l'événement sélectionné
    gint id_event;
    gchar *nom_event = NULL;
    gtk_tree_model_get(model, &iter, 0, &id_event, 1, &nom_event, -1);
    
    // Inscrire le membre à l'événement
    int result = inscrire_membre_event(cin, id_event);
    
    GtkWidget *dialog;
    if (result == 1) {
        dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK,
            "Inscription réussie à l'événement \"%s\" !", nom_event);
    } else if (result == -1) {
        dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK,
            "Événement introuvable !");
    } else if (result == -2) {
        dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Vous êtes déjà inscrit à cet événement !");
    } else {
        dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK,
            "Erreur lors de l'inscription !");
    }
    
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
    g_free(nom_event);
}

void on_button_voir_mes_inscription_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    // Récupérer le CIN du membre
    GtkWidget *entry_cin = lookup_widget(window, "entry_cin_inscription_hela");
    const gchar *cin = gtk_entry_get_text(GTK_ENTRY(entry_cin));
    
    // Vérifier que le CIN n'est pas vide
    if (strlen(cin) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Veuillez entrer votre CIN !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    // Créer une nouvelle fenêtre pour afficher les inscriptions
    GtkWidget *dialog_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(dialog_window), "Mes Inscriptions");
    gtk_window_set_default_size(GTK_WINDOW(dialog_window), 900, 500);
    gtk_window_set_position(GTK_WINDOW(dialog_window), GTK_WIN_POS_CENTER);
    gtk_window_set_modal(GTK_WINDOW(dialog_window), TRUE);
    gtk_window_set_transient_for(GTK_WINDOW(dialog_window), GTK_WINDOW(window));
    
    // Stocker le CIN dans la fenêtre pour pouvoir le réutiliser
    g_object_set_data_full(G_OBJECT(dialog_window), "cin_membre", 
                          g_strdup(cin), (GDestroyNotify)g_free);
    
    // Créer un conteneur vertical
    GtkWidget *vbox = gtk_vbox_new(FALSE, 10);
    gtk_container_add(GTK_CONTAINER(dialog_window), vbox);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 10);
    
    // Ajouter un label avec le CIN et statistiques
    int nb_inscriptions = compter_inscriptions_membre(cin);
    float total = calculer_total_inscriptions(cin);
    
    gchar *info_text = g_strdup_printf(
        "CIN: %s\nNombre d'inscriptions: %d\nMontant total: %.2f DT",
        cin, nb_inscriptions, total
    );
    
    GtkWidget *label_info = gtk_label_new(info_text);
    gtk_box_pack_start(GTK_BOX(vbox), label_info, FALSE, FALSE, 5);
    g_free(info_text);
    
    // Créer un scrolled window pour le treeview
    GtkWidget *scrolled = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled),
                                   GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled, TRUE, TRUE, 0);
    
    // Créer le treeview
    GtkWidget *treeview = gtk_tree_view_new();
    gtk_container_add(GTK_CONTAINER(scrolled), treeview);
    
    // Afficher les inscriptions du membre
    afficher_inscriptions_membre(treeview, cin);
    
    // Ajouter un bouton pour supprimer une inscription
    GtkWidget *hbox_buttons = gtk_hbox_new(FALSE, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox_buttons, FALSE, FALSE, 5);
    
    GtkWidget *button_supprimer = gtk_button_new_with_label("Annuler l'inscription sélectionnée");
    gtk_box_pack_start(GTK_BOX(hbox_buttons), button_supprimer, FALSE, FALSE, 5);
    
    // Callback pour supprimer l'inscription - pass treeview as user_data
    g_signal_connect(button_supprimer, "clicked",
        G_CALLBACK(on_button_annuler_inscription_clicked),
        treeview);
    
    GtkWidget *button_fermer = gtk_button_new_with_label("Fermer");
    gtk_box_pack_start(GTK_BOX(hbox_buttons), button_fermer, FALSE, FALSE, 5);
    
    g_signal_connect_swapped(button_fermer, "clicked",
        G_CALLBACK(gtk_widget_destroy),
        dialog_window);
    
    gtk_widget_show_all(dialog_window);
}

void on_button_annuler_inscription_clicked(GtkButton *button, gpointer user_data) {
    // user_data contains the treeview widget
    GtkWidget *treeview = GTK_WIDGET(user_data);
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *window = gtk_widget_get_toplevel(treeview);
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Veuillez sélectionner une inscription à annuler !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    // Récupérer l'ID de l'inscription
    gint id_inscription;
    gchar *nom_event = NULL;
    gtk_tree_model_get(model, &iter, 0, &id_inscription, 2, &nom_event, -1);
    
    GtkWidget *window = gtk_widget_get_toplevel(treeview);
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
        GTK_DIALOG_MODAL, GTK_MESSAGE_QUESTION, GTK_BUTTONS_YES_NO,
        "Voulez-vous vraiment annuler votre inscription à \"%s\" ?", nom_event);
    
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_YES) {
        supprimer_inscription_event(id_inscription);
        
        // Rafraîchir le treeview - récupérer le CIN depuis le parent
        GtkWidget *parent_window = gtk_widget_get_toplevel(GTK_WIDGET(button));
        const gchar *cin = g_object_get_data(G_OBJECT(parent_window), "cin_membre");
        
        if (cin) {
            afficher_inscriptions_membre(treeview, cin);
        }
        
        GtkWidget *ok_dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK,
            "Inscription annulée avec succès !");
        gtk_dialog_run(GTK_DIALOG(ok_dialog));
        gtk_widget_destroy(ok_dialog);
    }
    
    gtk_widget_destroy(dialog);
    g_free(nom_event);
}

void on_treeview_sincrire_event_row_activated(GtkTreeView *treeview,
                                               GtkTreePath *path,
                                               GtkTreeViewColumn *column,
                                               gpointer user_data)
{
    // Double-clic pour voir les détails de l'événement
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    model = gtk_tree_view_get_model(treeview);
    
    if (gtk_tree_model_get_iter(model, &iter, path)) {
        gint id_event;
        gchar *nom = NULL;
        gchar *type = NULL;
        gchar *centre = NULL;
        gchar *salle = NULL;
        gchar *date = NULL;
        gchar *heure = NULL;
        gchar *prix = NULL;
        gchar *statut = NULL;
        
        // Récupérer toutes les informations de l'événement
        gtk_tree_model_get(model, &iter,
                          0, &id_event,
                          1, &nom,
                          2, &type,
                          3, &centre,
                          4, &salle,
                          5, &date,
                          6, &heure,
                          7, &prix,
                          8, &statut,
                          -1);
        
        // Récupérer l'événement complet pour avoir la description
        evenement ev = trouver_evenement(id_event);
        
        // Créer un dialogue pour afficher les détails
        GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(treeview));
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Détails de l'événement");
        
        // Formater le message avec tous les détails
        gchar *message = g_strdup_printf(
            "<b>Nom:</b> %s\n"
            "<b>Type:</b> %s\n"
            "<b>Centre:</b> %s\n"
            "<b>Salle:</b> %s\n"
            "<b>Date:</b> %s\n"
            "<b>Heure:</b> %s\n"
            "<b>Prix:</b> %s\n"
            "<b>Statut:</b> %s\n\n"
            "<b>Description:</b>\n%s",
            nom ? nom : "N/A",
            type ? type : "N/A",
            centre ? centre : "N/A",
            salle ? salle : "N/A",
            date ? date : "N/A",
            heure ? heure : "N/A",
            prix ? prix : "N/A",
            statut ? statut : "N/A",
            ev.description
        );
        
        gtk_message_dialog_set_markup(GTK_MESSAGE_DIALOG(dialog), message);
        
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        
        // Libérer la mémoire
        g_free(message);
        g_free(nom);
        g_free(type);
        g_free(centre);
        g_free(salle);
        g_free(date);
        g_free(heure);
        g_free(prix);
        g_free(statut);
    }
}

void on_treeview_sincrire_event_cursor_changed(GtkTreeView *treeview,
                                               gpointer user_data)
{
    // Afficher un aperçu rapide de l'événement sélectionné dans la barre de statut
    // ou mettre à jour des informations dans l'interface
    
    GtkTreeSelection *selection;
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    selection = gtk_tree_view_get_selection(treeview);
    
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        gint id_event;
        gchar *nom = NULL;
        gchar *prix = NULL;
        
        gtk_tree_model_get(model, &iter,
                          0, &id_event,
                          1, &nom,
                          7, &prix,
                          -1);
        
        // Vous pouvez utiliser cette information pour mettre à jour l'interface
        // Par exemple, afficher le nom et le prix dans un label de statut
        // Pour l'instant, on utilise juste le tooltip
        gchar *tooltip = g_strdup_printf(
            "Événement sélectionné: %s (Prix: %s)\nDouble-cliquez pour voir les détails complets",
            nom ? nom : "N/A",
            prix ? prix : "N/A"
        );
        
        gtk_widget_set_tooltip_text(GTK_WIDGET(treeview), tooltip);
        
        g_free(tooltip);
        g_free(nom);
        g_free(prix);
    } else {
        gtk_widget_set_tooltip_text(GTK_WIDGET(treeview), 
            "Sélectionnez un événement pour vous inscrire");
    }
}



