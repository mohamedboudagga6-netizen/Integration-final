#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <ctype.h>
#include <gtk/gtk.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Entraineur.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"

// Chemin vers le fichier des entraineurs (fichiers dans le même répertoire que
// l'exécutable)
#define FILE_ENTRAINEURS "entraineurs.txt"
#define FILE_INSCRIPTIONS "inscriptions.txt"

// Variables globales pour stocker l'état
static char id_selected[20] = "";
static GtkWidget *current_treeview = NULL;

#define DEBUG_PRINT(msg)                                                       \
  g_print("[DEBUG] %s:%d - %s\n", __FILE__, __LINE__, msg)

// ==================== FONCTIONS UTILITAIRES ====================

void afficher_message(GtkWidget *parent, const char *message,
                      GtkMessageType type) {
  DEBUG_PRINT("Début afficher_message");

  if (!parent || !GTK_IS_WIDGET(parent)) {
    g_warning("Parent est NULL ou invalide dans afficher_message!");
    return;
  }

  // Vérifier que le parent est toujours valide
  if (!gtk_widget_get_visible(parent) && !GTK_IS_WINDOW(parent)) {
    g_warning("Parent n'est pas visible dans afficher_message!");
    return;
  }

  GtkWidget *dialog = gtk_message_dialog_new(
      GTK_WINDOW(parent), GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
      type, GTK_BUTTONS_OK, "%s", message);

  if (dialog) {
    DEBUG_PRINT("Dialog créé");
    gtk_dialog_run(GTK_DIALOG(dialog));
    DEBUG_PRINT("Dialog fermé");
    gtk_widget_destroy(dialog);
  }

  DEBUG_PRINT("Fin afficher_message");
}

char *get_entry_text(GtkWidget *entry) {
  if (!entry) {
    g_warning("Entry est NULL dans get_entry_text!");
    return "";
  }
  return (char *)gtk_entry_get_text(GTK_ENTRY(entry));
}

void set_entry_text(GtkWidget *entry, const char *text) {
  if (!entry) {
    g_warning("Entry est NULL dans set_entry_text!");
    return;
  }
  gtk_entry_set_text(GTK_ENTRY(entry), text);
}

void set_textview_text(GtkWidget *textview, const char *text) {
  if (!textview)
    return;
  GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
  gtk_text_buffer_set_text(buffer, text, -1);
}

char *format_date(int jour, int mois, int annee) {
  static char date_str[32];
  snprintf(date_str, sizeof(date_str), "%02d/%02d/%04d", jour, mois, annee);
  return date_str;
}

// ==================== GESTION DU TREEVIEW ====================

void afficher_entraineurs(GtkWidget *treeview) {
  DEBUG_PRINT("Début afficher_entraineurs");

  // Afficher le répertoire courant pour debug
  char cwd[1024];
  if (getcwd(cwd, sizeof(cwd)) != NULL) {
    g_print("[DEBUG] Répertoire courant: %s\n", cwd);
  }
  g_print("[DEBUG] Tentative d'ouverture: entraineurs.txt\n");

  if (!treeview) {
    g_warning("TreeView est NULL!");
    return;
  }

  GtkListStore *store;
  GtkTreeIter iter;
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GList *columns;
  int num_columns;

  // Vérifier correctement si les colonnes existent déjà
  columns = gtk_tree_view_get_columns(GTK_TREE_VIEW(treeview));
  num_columns = g_list_length(columns);
  g_list_free(columns);

  // Créer les colonnes SEULEMENT si elles n'existent pas
  if (num_columns == 0) {
    DEBUG_PRINT("Création des colonnes");
    renderer = gtk_cell_renderer_text_new();

    column = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", 0,
                                                      NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text",
                                                      1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Prénom", renderer,
                                                      "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Téléphone", renderer,
                                                      "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",
                                                      4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Spécialité", renderer,
                                                      "text", 5, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
  } else {
    DEBUG_PRINT("Colonnes déjà créées, rafraîchissement du contenu seulement");
  }

  DEBUG_PRINT("Création du store");
  store = gtk_list_store_new(6, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                             G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

  DEBUG_PRINT("Lecture du fichier");
  g_print("\n========================================\n");
  g_print("AFFICHER_ENTRAINEURS - Tentative lecture\n");
  g_print("Fichier: %s\n", FILE_ENTRAINEURS);
  g_print("========================================\n");

  FILE *f = fopen(FILE_ENTRAINEURS, "r");
  if (f != NULL) {
    g_print("✓ Fichier OUVERT avec succès!\n");
    char ligne[1024];
    int count = 0;

    while (fgets(ligne, sizeof(ligne), f) != NULL) {
      Entraineur E;

      // Parser la ligne manuellement pour gérer les champs vides
      char *token;
      char *saveptr;
      int field = 0;

      // Copier la ligne car strtok_r la modifie
      char ligne_copy[1024];
      strncpy(ligne_copy, ligne, sizeof(ligne_copy) - 1);
      ligne_copy[sizeof(ligne_copy) - 1] = '\0';

      // Nettoyer le saut de ligne
      ligne_copy[strcspn(ligne_copy, "\n")] = '\0';

      // Ignorer les lignes vides
      if (strlen(ligne_copy) == 0)
        continue;

      token = strtok_r(ligne_copy, "|", &saveptr);
      while (token != NULL && field < 12) {
        switch (field) {
        case 0:
          strncpy(E.id, token, sizeof(E.id) - 1);
          E.id[sizeof(E.id) - 1] = '\0';
          break;
        case 1:
          strncpy(E.nom, token, sizeof(E.nom) - 1);
          E.nom[sizeof(E.nom) - 1] = '\0';
          break;
        case 2:
          strncpy(E.prenom, token, sizeof(E.prenom) - 1);
          E.prenom[sizeof(E.prenom) - 1] = '\0';
          break;
        case 3:
          strncpy(E.mot_de_passe, token, sizeof(E.mot_de_passe) - 1);
          E.mot_de_passe[sizeof(E.mot_de_passe) - 1] = '\0';
          break;
        case 4:
          strncpy(E.telephone, token, sizeof(E.telephone) - 1);
          E.telephone[sizeof(E.telephone) - 1] = '\0';
          break;
        case 5:
          strncpy(E.sexe, token, sizeof(E.sexe) - 1);
          E.sexe[sizeof(E.sexe) - 1] = '\0';
          break;
        case 6:
          strncpy(E.photo, token, sizeof(E.photo) - 1);
          E.photo[sizeof(E.photo) - 1] = '\0';
          break;
        case 7:
          strncpy(E.cv, token, sizeof(E.cv) - 1);
          E.cv[sizeof(E.cv) - 1] = '\0';
          break;
        case 8:
          strncpy(E.specialite, token, sizeof(E.specialite) - 1);
          E.specialite[sizeof(E.specialite) - 1] = '\0';
          break;
        case 9:
          E.date_naissance.jour = atoi(token);
          break;
        case 10:
          E.date_naissance.mois = atoi(token);
          break;
        case 11:
          E.date_naissance.annee = atoi(token);
          break;
        }
        field++;
        token = strtok_r(NULL, "|", &saveptr);
      }

      if (field >= 12) { // Vérifier qu'on a tous les champs
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, E.id, 1, E.nom, 2, E.prenom, 3,
                           E.telephone, 4, E.sexe, 5, E.specialite, -1);
        count++;
      }
    }
    fclose(f);
    g_print("[DEBUG] %d entraîneurs chargés\n", count);
  } else {
    DEBUG_PRINT("Fichier entraineurs.txt non trouvé ou erreur de lecture");
  }

  gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
  g_object_unref(store);

  DEBUG_PRINT("Fin afficher_entraineurs");
}

void on_treeview_row_activated(GtkTreeView *treeview, GtkTreePath *path,
                               GtkTreeViewColumn *column, gpointer user_data) {
  DEBUG_PRINT("Début on_treeview_row_activated");

  GtkTreeModel *model;
  GtkTreeIter iter;
  gchar *id;

  model = gtk_tree_view_get_model(treeview);
  if (gtk_tree_model_get_iter(model, &iter, path)) {
    gtk_tree_model_get(model, &iter, 0, &id, -1);
    strcpy(id_selected, id);
    g_print("========================================\n");
    g_print("✓ LIGNE SÉLECTIONNÉE (double-clic)\n");
    g_print("ID sélectionné: '%s'\n", id_selected);
    g_print("========================================\n\n");
    g_free(id);
    current_treeview = GTK_WIDGET(treeview);
  }

  DEBUG_PRINT("Fin on_treeview_row_activated");
}

// Gestionnaire pour la sélection simple (un seul clic)
void on_treeview_cursor_changed(GtkTreeView *treeview, gpointer user_data) {
  DEBUG_PRINT("Début on_treeview_cursor_changed");

  GtkTreeSelection *selection;
  GtkTreeModel *model;
  GtkTreeIter iter;
  gchar *id;

  selection = gtk_tree_view_get_selection(treeview);
  if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
    gtk_tree_model_get(model, &iter, 0, &id, -1);
    strcpy(id_selected, id);
    g_print("========================================\n");
    g_print("✓ LIGNE SÉLECTIONNÉE (simple clic)\n");
    g_print("ID sélectionné: '%s'\n", id_selected);
    g_print("========================================\n\n");
    g_free(id);
    current_treeview = GTK_WIDGET(treeview);
  } else {
    g_print("[DEBUG] Pas de sélection\n");
  }

  DEBUG_PRINT("Fin on_treeview_cursor_changed");
}

// ==================== CALLBACKS LOGIN ====================

void on_button47_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button47_mohamed_clicked (Espace Admin)");

  GtkWidget *login_mohamed = gtk_widget_get_toplevel(button);
  g_print("[DEBUG] login_mohamed = %p\n", (void *)login_mohamed);

  GtkWidget *login_admin = create_login_admin_mohamed();
  g_print("[DEBUG] login_admin créé = %p\n", (void *)login_admin);

  DEBUG_PRINT("Destruction de login_mohamed");
  gtk_widget_destroy(login_mohamed);

  DEBUG_PRINT("Affichage de login_admin");
  gtk_window_set_default_size(GTK_WINDOW(login_admin), 1024, 768);
  gtk_widget_show(login_admin);

  DEBUG_PRINT("FIN on_button47_mohamed_clicked");
}

void on_button48_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button48_mohamed_clicked (Espace Entraineur)");

  GtkWidget *login_mohamed = gtk_widget_get_toplevel(button);
  GtkWidget *login_entraineur = create_login_entraineur_mohamed();

  gtk_widget_destroy(login_mohamed);
  gtk_window_set_default_size(GTK_WINDOW(login_entraineur), 1024, 768);
  gtk_widget_show(login_entraineur);

  DEBUG_PRINT("FIN on_button48_mohamed_clicked");
}

void on_button54_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button54_mohamed_clicked (Login Admin)");

  GtkWidget *login_admin = gtk_widget_get_toplevel(button);
  g_print("[DEBUG] login_admin toplevel = %p\n", (void *)login_admin);

  DEBUG_PRINT("Récupération des entries");
  GtkWidget *entry_id = lookup_widget(button, "entry52_mohamed");
  GtkWidget *entry_mdp = lookup_widget(button, "entry53_mohamed");

  g_print("[DEBUG] entry_id = %p, entry_mdp = %p\n", (void *)entry_id,
          (void *)entry_mdp);

  if (!entry_id || !entry_mdp) {
    g_warning("Les entries sont NULL!");
    return;
  }

  char *id = get_entry_text(entry_id);
  char *mdp = get_entry_text(entry_mdp);

  g_print("[DEBUG] ID saisi: '%s', MDP: '%s'\n", id, mdp);

  if (strcmp(id, "admin") == 0 && strcmp(mdp, "admin123") == 0) {
    DEBUG_PRINT("Login réussi, création de l'accueil");

    GtkWidget *acceuil = create_acceuil_mohamed();
    g_print("[DEBUG] acceuil créé = %p\n", (void *)acceuil);

    GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");
    g_print("[DEBUG] treeview = %p\n", (void *)treeview);

    if (treeview) {
      DEBUG_PRINT("Affichage des entraîneurs");
      afficher_entraineurs(treeview);
      g_signal_connect(G_OBJECT(treeview), "row-activated",
                       G_CALLBACK(on_treeview_row_activated), NULL);
      g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                       G_CALLBACK(on_treeview_cursor_changed), NULL);
    } else {
      g_warning("TreeView est NULL!");
    }

    DEBUG_PRINT("Destruction de login_admin");
    gtk_widget_destroy(login_admin);

    DEBUG_PRINT("Affichage de l'accueil");
    gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
    gtk_widget_show(acceuil);

    DEBUG_PRINT("Login admin terminé avec succès");
  } else {
    DEBUG_PRINT("Login échoué");
    afficher_message(login_admin, "Identifiant ou mot de passe incorrect!",
                     GTK_MESSAGE_ERROR);
  }

  DEBUG_PRINT("FIN on_button54_mohamed_clicked");
}

void on_button53_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("Annuler Login Admin");

  GtkWidget *login_admin = gtk_widget_get_toplevel(button);
  GtkWidget *login_mohamed = create_login_mohamed();

  gtk_widget_destroy(login_admin);
  gtk_window_set_default_size(GTK_WINDOW(login_mohamed), 1024, 768);
  gtk_widget_show(login_mohamed);
}

// ==================== CALLBACKS ACCUEIL ====================

void on_button70_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button70_mohamed_clicked (Ajouter)");

  GtkWidget *acceuil = gtk_widget_get_toplevel(button);
  GtkWidget *ajouter = create_ajouter_un_entraineur_mohamed();

  gtk_widget_destroy(acceuil);
  gtk_window_set_default_size(GTK_WINDOW(ajouter), 1024, 768);
  gtk_widget_show(ajouter);

  DEBUG_PRINT("FIN on_button70_mohamed_clicked");
}

void on_button55_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button55_mohamed_clicked (Enregistrer)");

  GtkWidget *window_ajouter = gtk_widget_get_toplevel(button);
  g_print("[DEBUG] window_ajouter = %p\n", (void *)window_ajouter);

  DEBUG_PRINT("Récupération de TOUS les widgets");

  // --- Récupération des entries ---
  GtkWidget *entry_id = lookup_widget(window_ajouter, "entry57_mohamed");
  GtkWidget *entry_nom = lookup_widget(window_ajouter, "entry56_mohamed");
  GtkWidget *entry_prenom = lookup_widget(window_ajouter, "entry55_mohamed");
  GtkWidget *entry_mdp = lookup_widget(window_ajouter, "entry54_mohamed");
  GtkWidget *entry_tel = lookup_widget(window_ajouter, "entry58_mohamed");

  // --- Récupération des autres widgets ---
  GtkWidget *checkbox = lookup_widget(window_ajouter, "checkbutton4_mohamed");
  GtkWidget *calendar = lookup_widget(window_ajouter, "calendar3_mohamed");
  GtkWidget *radio_homme =
      lookup_widget(window_ajouter, "radiobutton17_mohamed");
  GtkWidget *radio_femme =
      lookup_widget(window_ajouter, "radiobutton18_mohamed");
  GtkWidget *combobox = lookup_widget(window_ajouter, "comboboxentry6_mohamed");

  g_print("[DEBUG] Widgets: id=%p nom=%p prenom=%p mdp=%p tel=%p\n",
          (void *)entry_id, (void *)entry_nom, (void *)entry_prenom,
          (void *)entry_mdp, (void *)entry_tel);
  g_print("[DEBUG] Autres: checkbox=%p calendar=%p radio_h=%p radio_f=%p "
          "combo=%p\n",
          (void *)checkbox, (void *)calendar, (void *)radio_homme,
          (void *)radio_femme, (void *)combobox);

  // --- Vérifier que tous les widgets existent ---
  if (!entry_id || !entry_nom || !entry_prenom || !entry_mdp || !entry_tel ||
      !checkbox || !calendar || !radio_homme || !radio_femme || !combobox) {
    g_warning("Un ou plusieurs widgets sont NULL!");
    afficher_message(window_ajouter, "Erreur interne: widgets non trouvés",
                     GTK_MESSAGE_ERROR);
    return;
  }

  // --- VALIDATION 1: Vérifier que le checkbox est coché ---
  if (!gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbox))) {
    afficher_message(
        window_ajouter,
        "Vous devez cocher la case de confirmation pour continuer!",
        GTK_MESSAGE_WARNING);
    return;
  }

  // --- Récupération des données ---
  Entraineur E;
  const char *id = get_entry_text(entry_id);
  const char *nom = get_entry_text(entry_nom);
  const char *prenom = get_entry_text(entry_prenom);
  const char *mdp = get_entry_text(entry_mdp);
  const char *tel = get_entry_text(entry_tel);

  g_print("[DEBUG] Données: ID='%s' Nom='%s' Prenom='%s'\n", id, nom, prenom);

  // --- VALIDATION 2: Champs obligatoires ---
  if (strlen(id) == 0) {
    afficher_message(window_ajouter, "L'identifiant est obligatoire!",
                     GTK_MESSAGE_WARNING);
    return;
  }
  if (strlen(nom) == 0) {
    afficher_message(window_ajouter, "Le nom est obligatoire!",
                     GTK_MESSAGE_WARNING);
    return;
  }
  if (strlen(prenom) == 0) {
    afficher_message(window_ajouter, "Le prénom est obligatoire!",
                     GTK_MESSAGE_WARNING);
    return;
  }
  if (strlen(mdp) == 0) {
    afficher_message(window_ajouter, "Le mot de passe est obligatoire!",
                     GTK_MESSAGE_WARNING);
    return;
  }
  if (strlen(tel) == 0) {
    afficher_message(window_ajouter, "Le téléphone est obligatoire!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  // --- VALIDATION 3: Vérifier l'unicité de l'ID ---
  if (idExiste(FILE_ENTRAINEURS, id)) {
    afficher_message(
        window_ajouter,
        "Cet identifiant existe déjà! Veuillez en choisir un autre.",
        GTK_MESSAGE_ERROR);
    return;
  }

  // --- VALIDATION 4: Mot de passe (8+ caractères, maj, min, chiffres) ---
  if (!validerMotDePasse(mdp)) {
    afficher_message(
        window_ajouter,
        "Le mot de passe doit contenir au moins 8 caractères, incluant:\n"
        "- Au moins une majuscule\n"
        "- Au moins une minuscule\n"
        "- Au moins un chiffre",
        GTK_MESSAGE_WARNING);
    return;
  }

  // --- VALIDATION 5: Téléphone (8 chiffres) ---
  if (!validerTelephone(tel)) {
    afficher_message(
        window_ajouter,
        "Le numéro de téléphone doit contenir exactement 8 chiffres!",
        GTK_MESSAGE_WARNING);
    return;
  }

  // --- Récupération du SEXE depuis les radiobuttons ---
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_homme))) {
    strcpy(E.sexe, "Homme");
  } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_femme))) {
    strcpy(E.sexe, "Femme");
  } else {
    strcpy(E.sexe, "Homme"); // Par défaut
  }

  // --- Récupération de la SPÉCIALITÉ depuis le combobox ---
  gchar *specialite = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox));
  if (specialite && strlen(specialite) > 0) {
    strncpy(E.specialite, specialite, sizeof(E.specialite) - 1);
    E.specialite[sizeof(E.specialite) - 1] = '\0';
    g_free(specialite);
  } else {
    strcpy(E.specialite, "Musculation"); // Par défaut
  }

  // --- Récupération de la DATE depuis le calendrier ---
  guint year, month, day;
  gtk_calendar_get_date(GTK_CALENDAR(calendar), &year, &month, &day);
  E.date_naissance.jour = day;
  E.date_naissance.mois = month + 1; // GTK mois commence à 0
  E.date_naissance.annee = year;

  g_print("[DEBUG] Date: %d/%d/%d\n", E.date_naissance.jour,
          E.date_naissance.mois, E.date_naissance.annee);

  // --- VALIDATION 6: Date valide ---
  if (!validerDate(E.date_naissance.jour, E.date_naissance.mois,
                   E.date_naissance.annee)) {
    afficher_message(window_ajouter, "La date de naissance est invalide!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  // --- Copier les données validées ---
  strncpy(E.id, id, sizeof(E.id) - 1);
  E.id[sizeof(E.id) - 1] = '\0';
  strncpy(E.nom, nom, sizeof(E.nom) - 1);
  E.nom[sizeof(E.nom) - 1] = '\0';
  strncpy(E.prenom, prenom, sizeof(E.prenom) - 1);
  E.prenom[sizeof(E.prenom) - 1] = '\0';
  strncpy(E.mot_de_passe, mdp, sizeof(E.mot_de_passe) - 1);
  E.mot_de_passe[sizeof(E.mot_de_passe) - 1] = '\0';
  strncpy(E.telephone, tel, sizeof(E.telephone) - 1);
  E.telephone[sizeof(E.telephone) - 1] = '\0';

  strcpy(E.photo, "");
  strcpy(E.cv, "");

  g_print("[DEBUG] Toutes les validations passées. Ajout de: %s %s (ID: %s)\n",
          E.nom, E.prenom, E.id);

  // --- Ajout dans le fichier ---
  DEBUG_PRINT("Ajout dans le fichier");
  if (ajouter(FILE_ENTRAINEURS, E)) {
    g_print("[DEBUG] Entraineur ajouté avec succès: %s %s\n", E.nom, E.prenom);

    DEBUG_PRINT("Affichage du message de succès");
    afficher_message(window_ajouter, "Entraineur ajouté avec succès!",
                     GTK_MESSAGE_INFO);

    DEBUG_PRINT("Création de l'accueil");
    GtkWidget *acceuil = create_acceuil_mohamed();

    DEBUG_PRINT("Récupération du treeview");
    GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");

    if (treeview) {
      DEBUG_PRINT("Affichage des entraîneurs");
      afficher_entraineurs(treeview);
      g_signal_connect(G_OBJECT(treeview), "row-activated",
                       G_CALLBACK(on_treeview_row_activated), NULL);
      g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                       G_CALLBACK(on_treeview_cursor_changed), NULL);
    }

    DEBUG_PRINT("Destruction de la fenêtre ajout");
    gtk_widget_destroy(window_ajouter);

    DEBUG_PRINT("Affichage de l'accueil");
    gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
    gtk_widget_show(acceuil);

    DEBUG_PRINT("Enregistrement terminé avec succès");
  } else {
    g_warning("Erreur lors de l'ajout (ID existe déjà ou erreur fichier)!");
    afficher_message(window_ajouter,
                     "Erreur lors de l'ajout! L'ID existe peut-être déjà.",
                     GTK_MESSAGE_ERROR);
  }

  DEBUG_PRINT("FIN on_button55_mohamed_clicked");
}

void on_button56_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("Annuler Ajout");

  GtkWidget *window_ajouter = gtk_widget_get_toplevel(button);
  GtkWidget *acceuil = create_acceuil_mohamed();
  GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");

  if (treeview) {
    afficher_entraineurs(treeview);
    g_signal_connect(G_OBJECT(treeview), "row-activated",
                     G_CALLBACK(on_treeview_row_activated), NULL);
    g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                     G_CALLBACK(on_treeview_cursor_changed), NULL);
  }

  gtk_widget_destroy(window_ajouter);
  gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
  gtk_widget_show(acceuil);
}

// ==================== CALLBACKS RECHERCHE ====================

void on_button67_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button67_mohamed_clicked (Rechercher)");

  GtkWidget *acceuil = gtk_widget_get_toplevel(button);
  GtkWidget *entry_recherche = lookup_widget(acceuil, "entry71_mohamed");
  GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");

  if (!entry_recherche || !treeview) {
    g_warning("Widgets not found!");
    return;
  }

  char *id_recherche = get_entry_text(entry_recherche);

  if (strlen(id_recherche) == 0) {
    afficher_message(acceuil, "Veuillez saisir un ID à rechercher!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  Entraineur E = chercher(FILE_ENTRAINEURS, id_recherche);

  if (strcmp(E.id, "-1") == 0) {
    afficher_message(acceuil, "Aucun entraineur trouvé avec cet ID!",
                     GTK_MESSAGE_INFO);
    afficher_entraineurs(treeview);
  } else {
    GtkListStore *store =
        gtk_list_store_new(6, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                           G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    GtkTreeIter iter;
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, E.id, 1, E.nom, 2, E.prenom, 3,
                       E.telephone, 4, E.sexe, 5, E.specialite, -1);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);

    afficher_message(acceuil, "Entraineur trouvé!", GTK_MESSAGE_INFO);
  }

  DEBUG_PRINT("FIN on_button67_mohamed_clicked");
}

// ==================== CALLBACKS MODIFICATION ====================

void on_button69_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button69_mohamed_clicked (Ouvrir Modifier)");

  if (strlen(id_selected) == 0) {
    GtkWidget *acceuil = gtk_widget_get_toplevel(button);
    afficher_message(acceuil,
                     "Veuillez sélectionner un entraineur dans le tableau!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  GtkWidget *acceuil = gtk_widget_get_toplevel(button);
  GtkWidget *modifier_win = create_modifer_un_entraineur_mohamed();

  GtkWidget *entry_id = lookup_widget(modifier_win, "entry65_mohamed");
  if (entry_id) {
    set_entry_text(entry_id, id_selected);
  }

  gtk_widget_destroy(acceuil);
  gtk_window_set_default_size(GTK_WINDOW(modifier_win), 1024, 768);
  gtk_widget_show(modifier_win);

  DEBUG_PRINT("FIN on_button69_mohamed_clicked");
}

void on_button59_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button59_mohamed_clicked (Afficher données)");

  GtkWidget *modifier_win = gtk_widget_get_toplevel(button);
  GtkWidget *entry_id = lookup_widget(modifier_win, "entry65_mohamed");

  if (!entry_id)
    return;

  char *id = get_entry_text(entry_id);

  if (strlen(id) == 0) {
    afficher_message(modifier_win, "Veuillez saisir un ID!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  Entraineur E = chercher(FILE_ENTRAINEURS, id);

  if (strcmp(E.id, "-1") == 0) {
    afficher_message(modifier_win, "Entraineur non trouvé!", GTK_MESSAGE_ERROR);
    return;
  }

  set_textview_text(lookup_widget(modifier_win, "textview35_mohamed"), E.nom);
  set_textview_text(lookup_widget(modifier_win, "textview36_mohamed"),
                    E.prenom);
  set_textview_text(lookup_widget(modifier_win, "textview37_mohamed"), E.id);
  set_textview_text(lookup_widget(modifier_win, "textview38_mohamed"),
                    E.mot_de_passe);
  set_textview_text(lookup_widget(modifier_win, "textview39_mohamed"),
                    format_date(E.date_naissance.jour, E.date_naissance.mois,
                                E.date_naissance.annee));
  set_textview_text(lookup_widget(modifier_win, "textview40_mohamed"),
                    E.telephone);
  set_textview_text(lookup_widget(modifier_win, "textview41_mohamed"), E.sexe);

  set_entry_text(lookup_widget(modifier_win, "entry66_mohamed"), E.nom);
  set_entry_text(lookup_widget(modifier_win, "entry67_mohamed"), E.prenom);
  set_entry_text(lookup_widget(modifier_win, "entry68_mohamed"), E.id);
  set_entry_text(lookup_widget(modifier_win, "entry69_mohamed"),
                 E.mot_de_passe);
  set_entry_text(lookup_widget(modifier_win, "entry70_mohamed"), E.telephone);

  GtkWidget *spin_jour = lookup_widget(modifier_win, "spinbutton16_mohamed");
  GtkWidget *spin_mois = lookup_widget(modifier_win, "spinbutton17_mohamed");
  GtkWidget *spin_annee = lookup_widget(modifier_win, "spinbutton18_mohamed");

  if (spin_jour)
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_jour),
                              E.date_naissance.jour);
  if (spin_mois)
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_mois),
                              E.date_naissance.mois);
  if (spin_annee)
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_annee),
                              E.date_naissance.annee);

  GtkWidget *radio_homme = lookup_widget(modifier_win, "radiobutton21_mohamed");
  GtkWidget *radio_femme = lookup_widget(modifier_win, "radiobutton20_mohamed");

  if (strcmp(E.sexe, "Homme") == 0 && radio_homme)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio_homme), TRUE);
  else if (radio_femme)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio_femme), TRUE);

  afficher_message(modifier_win, "Données affichées avec succès!",
                   GTK_MESSAGE_INFO);

  DEBUG_PRINT("FIN on_button59_mohamed_clicked");
}

void on_button61_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button61_mohamed_clicked (Valider Modification)");

  GtkWidget *modifier_win = gtk_widget_get_toplevel(button);

  GtkWidget *checkbox = lookup_widget(modifier_win, "checkbutton5_mohamed");

  if (!checkbox || !gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbox))) {
    afficher_message(modifier_win, "Vous devez cocher la case de confirmation!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  GtkWidget *entry_id_old = lookup_widget(modifier_win, "entry65_mohamed");
  char *id_old = get_entry_text(entry_id_old);

  char *id_new = get_entry_text(lookup_widget(modifier_win, "entry68_mohamed"));
  char *nom = get_entry_text(lookup_widget(modifier_win, "entry66_mohamed"));
  char *prenom = get_entry_text(lookup_widget(modifier_win, "entry67_mohamed"));
  char *mdp = get_entry_text(lookup_widget(modifier_win, "entry69_mohamed"));
  char *tel = get_entry_text(lookup_widget(modifier_win, "entry70_mohamed"));

  if (strlen(nom) == 0 || strlen(prenom) == 0 || strlen(id_new) == 0 ||
      strlen(mdp) == 0 || strlen(tel) == 0) {
    afficher_message(modifier_win, "Tous les champs sont obligatoires!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  if (!validerMotDePasse(mdp)) {
    afficher_message(
        modifier_win,
        "Le mot de passe doit contenir au moins 8 caractères, incluant:\n"
        "- Au moins une majuscule\n"
        "- Au moins une minuscule\n"
        "- Au moins un chiffre",
        GTK_MESSAGE_WARNING);
    return;
  }

  if (!validerTelephone(tel)) {
    afficher_message(
        modifier_win,
        "Le numéro de téléphone doit contenir exactement 8 chiffres!",
        GTK_MESSAGE_WARNING);
    return;
  }

  if (strcmp(id_old, id_new) != 0) {
    if (idExiste(FILE_ENTRAINEURS, id_new)) {
      afficher_message(modifier_win, "Ce nouvel ID existe déjà!",
                       GTK_MESSAGE_ERROR);
      return;
    }
  }

  Entraineur E;
  strncpy(E.id, id_new, sizeof(E.id) - 1);
  E.id[sizeof(E.id) - 1] = '\0';
  strncpy(E.nom, nom, sizeof(E.nom) - 1);
  E.nom[sizeof(E.nom) - 1] = '\0';
  strncpy(E.prenom, prenom, sizeof(E.prenom) - 1);
  E.prenom[sizeof(E.prenom) - 1] = '\0';
  strncpy(E.mot_de_passe, mdp, sizeof(E.mot_de_passe) - 1);
  E.mot_de_passe[sizeof(E.mot_de_passe) - 1] = '\0';
  strncpy(E.telephone, tel, sizeof(E.telephone) - 1);
  E.telephone[sizeof(E.telephone) - 1] = '\0';

  GtkWidget *spin_jour = lookup_widget(modifier_win, "spinbutton16_mohamed");
  GtkWidget *spin_mois = lookup_widget(modifier_win, "spinbutton17_mohamed");
  GtkWidget *spin_annee = lookup_widget(modifier_win, "spinbutton18_mohamed");

  E.date_naissance.jour =
      spin_jour ? gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_jour))
                : 1;
  E.date_naissance.mois =
      spin_mois ? gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_mois))
                : 1;
  E.date_naissance.annee =
      spin_annee ? gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_annee))
                 : 1990;

  if (!validerDate(E.date_naissance.jour, E.date_naissance.mois,
                   E.date_naissance.annee)) {
    afficher_message(modifier_win, "La date de naissance est invalide!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  GtkWidget *radio_homme = lookup_widget(modifier_win, "radiobutton21_mohamed");
  GtkWidget *radio_femme = lookup_widget(modifier_win, "radiobutton20_mohamed");

  if (radio_homme &&
      gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_homme)))
    strcpy(E.sexe, "Homme");
  else if (radio_femme &&
           gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_femme)))
    strcpy(E.sexe, "Femme");
  else
    strcpy(E.sexe, "Homme");

  strcpy(E.photo, "");
  strcpy(E.cv, "");
  strcpy(E.specialite, "Musculation");

  if (modifier(FILE_ENTRAINEURS, id_old, E)) {
    afficher_message(modifier_win, "Entraineur modifié avec succès!",
                     GTK_MESSAGE_INFO);

    strcpy(id_selected, "");

    GtkWidget *acceuil = create_acceuil_mohamed();
    GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");
    if (treeview) {
      afficher_entraineurs(treeview);
      g_signal_connect(G_OBJECT(treeview), "row-activated",
                       G_CALLBACK(on_treeview_row_activated), NULL);
      g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                       G_CALLBACK(on_treeview_cursor_changed), NULL);
    }
    gtk_widget_destroy(modifier_win);
    gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
    gtk_widget_show(acceuil);
  } else {
    afficher_message(modifier_win, "Erreur lors de la modification!",
                     GTK_MESSAGE_ERROR);
  }

  DEBUG_PRINT("FIN on_button61_mohamed_clicked");
}

void on_button60_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button60_mohamed_clicked (Annuler Modifier)");

  GtkWidget *modifier_win = gtk_widget_get_toplevel(button);
  GtkWidget *acceuil = create_acceuil_mohamed();

  GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");
  if (treeview) {
    afficher_entraineurs(treeview);
    g_signal_connect(G_OBJECT(treeview), "row-activated",
                     G_CALLBACK(on_treeview_row_activated), NULL);
    g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                     G_CALLBACK(on_treeview_cursor_changed), NULL);
  }

  gtk_widget_destroy(modifier_win);
  gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
  gtk_widget_show(acceuil);

  DEBUG_PRINT("FIN on_button60_mohamed_clicked");
}

// ==================== CALLBACKS SUPPRESSION ====================

void on_button68_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button68_mohamed_clicked (Supprimer)");

  if (strlen(id_selected) == 0) {
    GtkWidget *acceuil = gtk_widget_get_toplevel(button);
    afficher_message(acceuil,
                     "Veuillez sélectionner un entraineur à supprimer!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  GtkWidget *acceuil = gtk_widget_get_toplevel(button);
  GtkWidget *supprimer = create_supprimer_un_entraineur_mohamed();

  gtk_widget_destroy(acceuil);
  gtk_window_set_default_size(GTK_WINDOW(supprimer), 1024, 768);
  gtk_widget_show(supprimer);

  DEBUG_PRINT("FIN on_button68_mohamed_clicked");
}

void on_button10_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button10_mohamed_clicked (Confirmer Suppression)");

  GtkWidget *supprimer_win = gtk_widget_get_toplevel(button);

  if (supprimer(FILE_ENTRAINEURS, id_selected)) {
    afficher_message(supprimer_win, "Entraineur supprimé avec succès!",
                     GTK_MESSAGE_INFO);

    strcpy(id_selected, "");

    GtkWidget *acceuil = create_acceuil_mohamed();
    GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");
    if (treeview) {
      afficher_entraineurs(treeview);
      g_signal_connect(G_OBJECT(treeview), "row-activated",
                       G_CALLBACK(on_treeview_row_activated), NULL);
      g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                       G_CALLBACK(on_treeview_cursor_changed), NULL);
    }
    gtk_widget_destroy(supprimer_win);
    gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
    gtk_widget_show(acceuil);
  } else {
    afficher_message(supprimer_win, "Erreur lors de la suppression!",
                     GTK_MESSAGE_ERROR);
  }

  DEBUG_PRINT("FIN on_button10_mohamed_clicked");
}

void on_button15_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button15_mohamed_clicked (Annuler Suppression)");

  GtkWidget *supprimer_win = gtk_widget_get_toplevel(button);
  GtkWidget *acceuil = create_acceuil_mohamed();

  GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");
  if (treeview) {
    afficher_entraineurs(treeview);
    g_signal_connect(G_OBJECT(treeview), "row-activated",
                     G_CALLBACK(on_treeview_row_activated), NULL);
    g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                     G_CALLBACK(on_treeview_cursor_changed), NULL);
  }

  gtk_widget_destroy(supprimer_win);
  gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
  gtk_widget_show(acceuil);

  DEBUG_PRINT("FIN on_button15_mohamed_clicked");
}

// ==================== CALLBACKS INSCRIPTION COURS ====================

void afficher_inscriptions(GtkWidget *treeview) {
  DEBUG_PRINT("Début afficher_inscriptions");

  if (!treeview) {
    g_warning("TreeView est NULL!");
    return;
  }

  GtkListStore *store;
  GtkTreeIter iter;
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GList *columns;
  int num_columns;

  columns = gtk_tree_view_get_columns(GTK_TREE_VIEW(treeview));
  num_columns = g_list_length(columns);
  g_list_free(columns);

  if (num_columns == 0) {
    DEBUG_PRINT("Création des colonnes inscriptions");

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text",
                                                      0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Prénom", renderer,
                                                      "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Session", renderer,
                                                      "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Type de cours", renderer,
                                                      "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
  }

  store = gtk_list_store_new(4, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                             G_TYPE_STRING);

  FILE *f = fopen(FILE_INSCRIPTIONS, "r");
  if (f != NULL) {
    char ligne[512];
    int count = 0;

    while (fgets(ligne, sizeof(ligne), f) != NULL) {
      Inscription I;
      char *token, *saveptr;
      int field = 0;

      ligne[strcspn(ligne, "\n")] = '\0';
      if (strlen(ligne) == 0)
        continue;

      token = strtok_r(ligne, "|", &saveptr);
      while (token != NULL && field < 4) {
        switch (field) {
        case 0:
          strncpy(I.nom, token, sizeof(I.nom) - 1);
          I.nom[sizeof(I.nom) - 1] = '\0';
          break;
        case 1:
          strncpy(I.prenom, token, sizeof(I.prenom) - 1);
          I.prenom[sizeof(I.prenom) - 1] = '\0';
          break;
        case 2:
          strncpy(I.session, token, sizeof(I.session) - 1);
          I.session[sizeof(I.session) - 1] = '\0';
          break;
        case 3:
          strncpy(I.type_cours, token, sizeof(I.type_cours) - 1);
          I.type_cours[sizeof(I.type_cours) - 1] = '\0';
          break;
        }
        field++;
        token = strtok_r(NULL, "|", &saveptr);
      }

      if (field >= 4) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, I.nom, 1, I.prenom, 2, I.session, 3,
                           I.type_cours, -1);
        count++;
      }
    }
    fclose(f);
    g_print("[DEBUG] %d inscriptions chargées\n", count);
  }

  gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
  g_object_unref(store);

  DEBUG_PRINT("Fin afficher_inscriptions");
}

void on_button77_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button77_mohamed_clicked (Valider Inscription)");

  GtkWidget *inscrire = gtk_widget_get_toplevel(button);

  GtkWidget *checkbox = lookup_widget(inscrire, "checkbutton7_mohamed");

  if (!checkbox || !gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbox))) {
    afficher_message(inscrire, "Vous devez cocher la case de confirmation!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  GtkWidget *entry_nom = lookup_widget(inscrire, "entry74_mohamed");
  GtkWidget *entry_prenom = lookup_widget(inscrire, "entry75_mohamed");

  char *nom = get_entry_text(entry_nom);
  char *prenom = get_entry_text(entry_prenom);

  if (strlen(nom) == 0 || strlen(prenom) == 0) {
    afficher_message(inscrire, "Le nom et le prénom sont obligatoires!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  GtkWidget *radio_jour = lookup_widget(inscrire, "radiobutton22_mohamed");
  GtkWidget *radio_soir = lookup_widget(inscrire, "radiobutton23_mohamed");

  char session[20];
  if (radio_jour && gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_jour)))
    strcpy(session, "jour");
  else if (radio_soir &&
           gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_soir)))
    strcpy(session, "soir");
  else
    strcpy(session, "jour");

  GtkWidget *combobox = lookup_widget(inscrire, "comboboxentry7_mohamed");
  gchar *type_cours = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox));

  if (!type_cours || strlen(type_cours) == 0) {
    afficher_message(inscrire, "Veuillez sélectionner un type de cours!",
                     GTK_MESSAGE_WARNING);
    if (type_cours)
      g_free(type_cours);
    return;
  }

  Inscription I;
  strncpy(I.nom, nom, sizeof(I.nom) - 1);
  I.nom[sizeof(I.nom) - 1] = '\0';
  strncpy(I.prenom, prenom, sizeof(I.prenom) - 1);
  I.prenom[sizeof(I.prenom) - 1] = '\0';
  strncpy(I.session, session, sizeof(I.session) - 1);
  I.session[sizeof(I.session) - 1] = '\0';
  strncpy(I.type_cours, type_cours, sizeof(I.type_cours) - 1);
  I.type_cours[sizeof(I.type_cours) - 1] = '\0';
  g_free(type_cours);

  if (inscrireCours(FILE_INSCRIPTIONS, I)) {
    afficher_message(inscrire, "Inscription réussie!", GTK_MESSAGE_INFO);

    GtkWidget *treeview = lookup_widget(inscrire, "treeview6_mohamed");
    if (treeview) {
      afficher_inscriptions(treeview);
    }

    set_entry_text(entry_nom, "");
    set_entry_text(entry_prenom, "");
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbox), FALSE);
  } else {
    afficher_message(inscrire, "Erreur lors de l'inscription!",
                     GTK_MESSAGE_ERROR);
  }

  DEBUG_PRINT("FIN on_button77_mohamed_clicked");
}

void on_button76_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button76_mohamed_clicked (Annuler Inscription)");

  GtkWidget *inscrire = gtk_widget_get_toplevel(button);
  GtkWidget *acceuil = create_acceuil_mohamed();

  GtkWidget *treeview = lookup_widget(acceuil, "treeview5_mohamed");
  if (treeview) {
    afficher_entraineurs(treeview);
    g_signal_connect(G_OBJECT(treeview), "row-activated",
                     G_CALLBACK(on_treeview_row_activated), NULL);
    g_signal_connect(G_OBJECT(treeview), "cursor-changed",
                     G_CALLBACK(on_treeview_cursor_changed), NULL);
  }

  gtk_widget_destroy(inscrire);
  gtk_window_set_default_size(GTK_WINDOW(acceuil), 1024, 768);
  gtk_widget_show(acceuil);

  DEBUG_PRINT("FIN on_button76_mohamed_clicked");
}

void on_button78_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button78_mohamed_clicked (Déconnexion Inscription)");

  GtkWidget *inscrire = gtk_widget_get_toplevel(button);
  GtkWidget *login_admin = create_login_admin_mohamed();

  gtk_widget_destroy(inscrire);
  gtk_window_set_default_size(GTK_WINDOW(login_admin), 1024, 768);
  gtk_widget_show(login_admin);

  DEBUG_PRINT("FIN on_button78_mohamed_clicked");
}

// ==================== CALLBACKS NAVIGATION ====================

void on_button71_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button71_mohamed_clicked (Précédent)");

  GtkWidget *acceuil = gtk_widget_get_toplevel(button);
  GtkWidget *login = create_login_mohamed();

  strcpy(id_selected, "");

  gtk_widget_destroy(acceuil);
  gtk_window_set_default_size(GTK_WINDOW(login), 1024, 768);
  gtk_widget_show(login);

  DEBUG_PRINT("FIN on_button71_mohamed_clicked");
}

void on_button72_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button72_mohamed_clicked (Déconnexion Accueil)");

  GtkWidget *acceuil = gtk_widget_get_toplevel(button);
  GtkWidget *login_admin = create_login_admin_mohamed();

  strcpy(id_selected, "");

  gtk_widget_destroy(acceuil);
  gtk_window_set_default_size(GTK_WINDOW(login_admin), 1024, 768);
  gtk_widget_show(login_admin);

  DEBUG_PRINT("FIN on_button72_mohamed_clicked");
}

void on_button62_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button62_mohamed_clicked (Déconnexion Modifier)");

  GtkWidget *modifier_win = gtk_widget_get_toplevel(button);
  GtkWidget *login_admin = create_login_admin_mohamed();

  strcpy(id_selected, "");

  gtk_widget_destroy(modifier_win);
  gtk_window_set_default_size(GTK_WINDOW(login_admin), 1024, 768);
  gtk_widget_show(login_admin);

  DEBUG_PRINT("FIN on_button62_mohamed_clicked");
}

void on_button63_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button63_mohamed_clicked (Déconnexion Ajouter)");

  GtkWidget *ajouter = gtk_widget_get_toplevel(button);
  GtkWidget *login_admin = create_login_admin_mohamed();

  gtk_widget_destroy(ajouter);
  gtk_window_set_default_size(GTK_WINDOW(login_admin), 1024, 768);
  gtk_widget_show(login_admin);

  DEBUG_PRINT("FIN on_button63_mohamed_clicked");
}

// ==================== CALLBACKS LOGIN ENTRAINEUR ====================

void on_button74_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button74_mohamed_clicked (Login Entraineur)");

  GtkWidget *login_entraineur = gtk_widget_get_toplevel(button);

  // Récupérer les entries
  GtkWidget *entry_id = lookup_widget(login_entraineur, "entry72_mohamed");
  GtkWidget *entry_mdp = lookup_widget(login_entraineur, "entry73_mohamed");

  if (!entry_id || !entry_mdp) {
    g_warning("Widgets entry non trouvés!");
    return;
  }

  char *id = get_entry_text(entry_id);
  char *mdp = get_entry_text(entry_mdp);

  g_print("[DEBUG LOGIN ENTRAINEUR] ID: '%s', MDP: '%s'\n", id, mdp);

  // Validation des champs vides
  if (strlen(id) == 0 || strlen(mdp) == 0) {
    afficher_message(login_entraineur,
                     "Veuillez saisir l'ID et le mot de passe!",
                     GTK_MESSAGE_WARNING);
    return;
  }

  // Chercher l'entraineur dans le fichier
  Entraineur E = chercher(FILE_ENTRAINEURS, id);

  if (strcmp(E.id, "-1") == 0) {
    afficher_message(login_entraineur, "ID inexistant!", GTK_MESSAGE_ERROR);
    return;
  }

  // Vérifier le mot de passe
  if (strcmp(E.mot_de_passe, mdp) != 0) {
    afficher_message(login_entraineur, "Mot de passe incorrect!",
                     GTK_MESSAGE_ERROR);
    return;
  }

  // Login réussi
  g_print("[DEBUG LOGIN ENTRAINEUR] Login réussi pour: %s %s\n", E.nom,
          E.prenom);
  afficher_message(login_entraineur, "Bienvenue!", GTK_MESSAGE_INFO);

  // Ouvrir l'interface d'inscription à un cours
  GtkWidget *inscrire = create_inscrire____un_cours_sportif_mohamed();

  // Connecter le TreeView des inscriptions
  GtkWidget *treeview_inscriptions =
      lookup_widget(inscrire, "treeview6_mohamed");
  if (treeview_inscriptions) {
    afficher_inscriptions(treeview_inscriptions);
  }

  gtk_widget_destroy(login_entraineur);
  gtk_window_set_default_size(GTK_WINDOW(inscrire), 1024, 768);
  gtk_widget_show(inscrire);

  DEBUG_PRINT("FIN on_button74_mohamed_clicked");
}

void on_button73_mohamed_clicked(GtkWidget *button, gpointer user_data) {
  DEBUG_PRINT("DÉBUT on_button73_mohamed_clicked (Annuler Login Entraineur)");

  GtkWidget *login_entraineur = gtk_widget_get_toplevel(button);
  GtkWidget *login = create_login_mohamed();

  gtk_widget_destroy(login_entraineur);
  gtk_window_set_default_size(GTK_WINDOW(login), 1024, 768);
  gtk_widget_show(login);

  DEBUG_PRINT("FIN on_button73_mohamed_clicked");
}
