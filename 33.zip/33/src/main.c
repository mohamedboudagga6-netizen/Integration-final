/*
 * Programme principal - Application Gestion Entraineurs
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "interface.h"
#include "support.h"
#include "callbacks.h"

int main (int argc, char *argv[])
{
  GtkWidget *login_window;

#ifdef ENABLE_NLS
  bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
  bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
  textdomain (GETTEXT_PACKAGE);
#endif

  gtk_set_locale ();
  gtk_init (&argc, &argv);

  // Ajouter les répertoires des images (plusieurs emplacements possibles)
  add_pixmap_directory ("../pixmaps");
  add_pixmap_directory ("pixmaps");
  add_pixmap_directory ("src/pixmaps");
  add_pixmap_directory (".");

  // Créer la fenêtre de login principale
  login_window = create_login_mohamed();
  gtk_widget_show (login_window);

  // Lancer la boucle principale GTK
  gtk_main ();
  
  return 0;
}

