#ifndef CALLBACKS_H
#define CALLBACKS_H

#include <gtk/gtk.h>

// Fonctions utilitaires
void afficher_message(GtkWidget *parent, const char *message, GtkMessageType type);
void afficher_entraineurs(GtkWidget *treeview);
void afficher_inscriptions(GtkWidget *treeview);
void on_treeview_row_activated(GtkTreeView *treeview, GtkTreePath *path,
                               GtkTreeViewColumn *column, gpointer user_data);
void on_treeview_cursor_changed(GtkTreeView *treeview, gpointer user_data);
void set_textview_text(GtkWidget *textview, const char *text);
char* format_date(int jour, int mois, int annee);

// Callbacks Login principal
void on_button47_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button48_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Login Admin
void on_button54_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button53_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Login Entraineur
void on_button74_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button73_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Accueil
void on_button67_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button70_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button69_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button68_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button71_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button72_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Ajouter
void on_button55_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button56_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button63_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Modifier
void on_button59_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button61_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button60_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button62_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Supprimer
void on_button10_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button15_mohamed_clicked(GtkWidget *button, gpointer user_data);

// Callbacks Inscription cours
void on_button77_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button76_mohamed_clicked(GtkWidget *button, gpointer user_data);
void on_button78_mohamed_clicked(GtkWidget *button, gpointer user_data);

#endif

